import React from 'react';
import './App.css';

function App() {
  return (
    <div className="app">
      <h1>RisparmioSmart</h1>
      <p>App base React pronta per Vercel</p>
    </div>
  );
}

export default App;